package ch.axonivy.demo;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Person", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Person extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 3964040727271772278L;

  private java.lang.String name;

  /**
   * Gets the field name.
   * @return the value of the field name; may be null.
   */
  public java.lang.String getName()
  {
    return name;
  }

  /**
   * Sets the field name.
   * @param _name the new value of the field name.
   */
  public void setName(java.lang.String _name)
  {
    name = _name;
  }

  private java.lang.Number age;

  /**
   * Gets the field age.
   * @return the value of the field age; may be null.
   */
  public java.lang.Number getAge()
  {
    return age;
  }

  /**
   * Sets the field age.
   * @param _age the new value of the field age.
   */
  public void setAge(java.lang.Number _age)
  {
    age = _age;
  }

}
