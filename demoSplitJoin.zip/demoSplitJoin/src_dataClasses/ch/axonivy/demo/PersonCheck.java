package ch.axonivy.demo;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PersonCheck", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PersonCheck extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 6685389518922041031L;

  private ch.axonivy.demo.Person person;

  /**
   * Gets the field person.
   * @return the value of the field person; may be null.
   */
  public ch.axonivy.demo.Person getPerson()
  {
    return person;
  }

  /**
   * Sets the field person.
   * @param _person the new value of the field person.
   */
  public void setPerson(ch.axonivy.demo.Person _person)
  {
    person = _person;
  }

  private java.lang.Boolean isOK;

  /**
   * Gets the field isOK.
   * @return the value of the field isOK; may be null.
   */
  public java.lang.Boolean getIsOK()
  {
    return isOK;
  }

  /**
   * Sets the field isOK.
   * @param _isOK the new value of the field isOK.
   */
  public void setIsOK(java.lang.Boolean _isOK)
  {
    isOK = _isOK;
  }

}
