package rules.engine.example.demo;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class demoData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class demoData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -3623193931093837992L;

  private java.lang.String firstName;

  /**
   * Gets the field firstName.
   * @return the value of the field firstName; may be null.
   */
  public java.lang.String getFirstName()
  {
    return firstName;
  }

  /**
   * Sets the field firstName.
   * @param _firstName the new value of the field firstName.
   */
  public void setFirstName(java.lang.String _firstName)
  {
    firstName = _firstName;
  }

  private java.lang.String lastName;

  /**
   * Gets the field lastName.
   * @return the value of the field lastName; may be null.
   */
  public java.lang.String getLastName()
  {
    return lastName;
  }

  /**
   * Sets the field lastName.
   * @param _lastName the new value of the field lastName.
   */
  public void setLastName(java.lang.String _lastName)
  {
    lastName = _lastName;
  }

  private java.lang.String middleName;

  /**
   * Gets the field middleName.
   * @return the value of the field middleName; may be null.
   */
  public java.lang.String getMiddleName()
  {
    return middleName;
  }

  /**
   * Sets the field middleName.
   * @param _middleName the new value of the field middleName.
   */
  public void setMiddleName(java.lang.String _middleName)
  {
    middleName = _middleName;
  }

}
