package ch.axonivy.demo;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class startDemoData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class startDemoData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -241067804697674388L;

  private java.util.List<ch.axonivy.demo.Person> persions;

  /**
   * Gets the field persions.
   * @return the value of the field persions; may be null.
   */
  public java.util.List<ch.axonivy.demo.Person> getPersions()
  {
    return persions;
  }

  /**
   * Sets the field persions.
   * @param _persions the new value of the field persions.
   */
  public void setPersions(java.util.List<ch.axonivy.demo.Person> _persions)
  {
    persions = _persions;
  }

  private java.util.List<ch.axonivy.demo.PersonCheck> persionCheck;

  /**
   * Gets the field persionCheck.
   * @return the value of the field persionCheck; may be null.
   */
  public java.util.List<ch.axonivy.demo.PersonCheck> getPersionCheck()
  {
    return persionCheck;
  }

  /**
   * Sets the field persionCheck.
   * @param _persionCheck the new value of the field persionCheck.
   */
  public void setPersionCheck(java.util.List<ch.axonivy.demo.PersonCheck> _persionCheck)
  {
    persionCheck = _persionCheck;
  }

  private ch.axonivy.demo.Person excutedPerson;

  /**
   * Gets the field excutedPerson.
   * @return the value of the field excutedPerson; may be null.
   */
  public ch.axonivy.demo.Person getExcutedPerson()
  {
    return excutedPerson;
  }

  /**
   * Sets the field excutedPerson.
   * @param _excutedPerson the new value of the field excutedPerson.
   */
  public void setExcutedPerson(ch.axonivy.demo.Person _excutedPerson)
  {
    excutedPerson = _excutedPerson;
  }

}
